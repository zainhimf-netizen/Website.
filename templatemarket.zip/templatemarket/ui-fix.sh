#!/data/data/com.termux/files/usr/bin/bash
set -u

ROOT="$PWD"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/backups/ui-fix-$STAMP"
REPORT="$ROOT/UI-FIX-REPORT.txt"

mkdir -p "$BACKUP"
FIXED=0
SKIPPED=0

{
echo "=========================================="
echo "TEMPLATEMARKET UI SAFE REPAIR"
echo "Date: $(date)"
echo "Project: $ROOT"
echo "Backup: $BACKUP"
echo "=========================================="

echo
echo "1. Fixing template-details page heading"

FILE="$ROOT/pages/template-details.html"
if [ -f "$FILE" ]; then
  if grep -qi '<h1[ >]' "$FILE"; then
    echo "SKIP: H1 already exists in template-details.html"
    SKIPPED=$((SKIPPED+1))
  else
    cp -p "$FILE" "$BACKUP/template-details.html"
    python - "$FILE" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding="utf-8")
heading = '<h1 class="page-title">Template Details</h1>'
# Prefer inserting the heading inside the main content container.
m = re.search(r'<main\b[^>]*>', s, re.I)
if m:
    s = s[:m.end()] + '\n    ' + heading + s[m.end():]
else:
    m = re.search(r'<body\b[^>]*>', s, re.I)
    if m:
        s = s[:m.end()] + '\n    ' + heading + s[m.end():]
    else:
        raise SystemExit("SKIP: No body/main element found; file unchanged.")
p.write_text(s, encoding="utf-8")
PY
    if grep -qi '<h1[ >]' "$FILE"; then
      echo "FIXED: Added a basic page heading."
      FIXED=$((FIXED+1))
    else
      echo "REVIEW: Heading could not be verified."
    fi
  fi
else
  echo "SKIP: pages/template-details.html not found."
fi

echo
echo "2. Checking all full HTML pages"
find "$ROOT/pages" -type f -iname '*.html' -print0 2>/dev/null |
while IFS= read -r -d '' f; do
  [ -s "$f" ] || echo "WARNING: Empty page: $f"
  grep -qi '<!doctype html' "$f" || echo "REVIEW: Missing DOCTYPE: $f"
  grep -qi '<title' "$f" || echo "REVIEW: Missing title: $f"
  grep -qi 'name=["'\'']viewport' "$f" || echo "REVIEW: Missing viewport meta: $f"
done

echo
echo "3. Checking local CSS and JavaScript files"
python - <<'PY'
from pathlib import Path
import re
root = Path.cwd()
skip = {"node_modules", ".git", "backups", "dist", "build"}
for f in root.rglob("*.html"):
    if any(x in skip for x in f.parts):
        continue
    try:
        s = f.read_text(encoding="utf-8", errors="replace")
    except OSError:
        continue
    for kind, pattern in [
        ("CSS", r'<link\b[^>]*href=["\']([^"\']+\.css(?:\?[^"\']*)?)["\']'),
        ("JS", r'<script\b[^>]*src=["\']([^"\']+\.js(?:\?[^"\']*)?)["\']')
    ]:
        for raw in re.findall(pattern, s, re.I):
            path = raw.split("?", 1)[0]
            if path.startswith(("http://", "https://", "//", "data:")):
                continue
            target = (root / path.lstrip("/")) if path.startswith("/") else (f.parent / path)
            if not target.exists():
                print(f"MISSING {kind}: {f.relative_to(root)} -> {raw}")
PY

echo
echo "4. Checking CSS for responsive and focus styles"
find "$ROOT/assets" -type f -iname '*.css' -print0 2>/dev/null |
while IFS= read -r -d '' f; do
  grep -q '@media' "$f" || echo "REVIEW: No @media rule found in $f"
  grep -Eq ':focus|focus-visible' "$f" || echo "REVIEW: No focus style found in $f"
done

echo
echo "5. Safety summary"
echo "Only the template-details heading was eligible for an automatic source edit."
echo "Component fragments were not changed."
echo "CSS colors, layouts, navigation, and JavaScript behavior require page-specific verification."
echo "Fixed counter: $FIXED"
echo "Skipped counter: $SKIPPED"
echo "Backup folder: $BACKUP"
echo "Report: $REPORT"
echo "REPAIR SCRIPT FINISHED"
} > "$REPORT" 2>&1

cat "$REPORT"
