# TemplateMarket

A responsive HTML, CSS and JavaScript starter for a premium digital-template marketplace.

## Project structure
- pages/: marketplace, customer, seller and admin pages
- components/: reusable UI components
- assets/css/: design system and responsive styles
- assets/js/: front-end modules
- data/: starter JSON data
- docs/: documentation
- tests/: manual test checklist

## Run
Open index.html in a browser, or use a local static server.

Note: authentication, payments, secure roles, database persistence and real analytics
must be implemented before production use.
