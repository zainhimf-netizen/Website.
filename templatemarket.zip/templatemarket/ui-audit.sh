#!/data/data/com.termux/files/usr/bin/bash
ROOT="$PWD"
REPORT="$ROOT/UI-SYSTEM-REPORT.txt"

{
echo "=========================================="
echo "TEMPLATEMARKET UI SYSTEM AUDIT"
echo "Date: $(date)"
echo "Project: $ROOT"
echo "=========================================="

echo
echo "1. FILE COUNTS"
for ext in html css js; do
  n=$(find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname "*.$ext" -print | wc -l)
  echo "$ext files: $n"
done

echo
echo "2. HTML PAGES"
find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname '*.html' -print | sort

echo
echo "3. EMPTY FILES"
find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -size 0 -print

echo
echo "4. HTML UI WARNINGS"
find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname '*.html' -print0 |
while IFS= read -r -d '' f; do
  [ -s "$f" ] || { echo "EMPTY HTML: $f"; continue; }
  grep -qi '<!doctype html' "$f" || echo "Missing DOCTYPE: $f"
  grep -qi '<title' "$f" || echo "Missing title: $f"
  grep -qi 'name="viewport"' "$f" || echo "Check viewport meta: $f"
  grep -qi '<h1' "$f" || echo "No H1 found: $f"
done

echo
echo "5. CSS RESPONSIVE / ACCESSIBILITY CHECK"
for term in '@media' 'focus-visible' 'prefers-reduced-motion' 'box-sizing'; do
  n=$(find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname '*.css' -print0 | xargs -0 -r grep -F -h -c "$term" 2>/dev/null | awk '{s+=$1} END {print s+0}')
  echo "$term occurrences: $n"
done

echo
echo "6. COMMON JAVASCRIPT WARNINGS"
find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname '*.js' -print0 |
xargs -0 -r grep -nE 'TODO|FIXME|console\.error|javascript:void\(0\)' 2>/dev/null || true

echo
echo "7. POSSIBLE EMPTY BUTTONS / LINKS"
find . -type d \( -name node_modules -o -name .git -o -name dist -o -name build \) -prune -o -type f -iname '*.html' -print0 |
while IFS= read -r -d '' f; do
  grep -nEi '<button[^>]*>[[:space:]]*</button>|<a[^>]*>[[:space:]]*</a>' "$f" 2>/dev/null | sed "s#^#$f: #"
done

echo
echo "8. TOP-LEVEL PROJECT CONTENTS"
ls -la

echo
echo "9. LIMITATIONS"
echo "This source audit cannot verify real browser appearance or click interactions."
echo "No project files were changed or deleted by the audit."
echo
echo "AUDIT COMPLETE"
} > "$REPORT" 2>&1

echo "Audit complete. Report saved to:"
echo "$REPORT"
cat "$REPORT"
