"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const current = window.location.pathname.replace(/\/+$/, "");
  document.querySelectorAll(".main-nav a").forEach((link) => {
    const target = new URL(link.href, window.location.href).pathname.replace(/\/+$/, "");
    if (target === current) link.classList.add("active");
  });
  document.querySelectorAll("[data-current-year]").forEach((node) => {
    node.textContent = String(new Date().getFullYear());
  });
  console.info("TemplateMarket Phase 1 UI loaded.");
});
