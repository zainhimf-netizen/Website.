"use strict";

const PROFILE_KEY = "templatemarket_demo_profile_v1";

function showMessage(text, type) {
  const node = document.getElementById("message");
  if (!node) return;
  node.textContent = text;
  node.className = "form-message show " + type;
}

function readProfile() {
  try {
    const value = localStorage.getItem(PROFILE_KEY);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const register = document.getElementById("register-form");
  if (register) register.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;
    const confirm = document.getElementById("confirm").value;

    if (name.length < 2) return showMessage("Enter your full name.", "error");
    if (password.length < 8) return showMessage("Use at least 8 characters for the password.", "error");
    if (password !== confirm) return showMessage("Passwords do not match.", "error");
    if (!document.getElementById("terms").checked) return showMessage("Please accept the terms to continue.", "error");

    // Intentionally do not store the password or pretend a server account exists.
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify({ name, email }));
      showMessage("Demo profile saved in this browser. Real account registration is not active yet.", "success");
      setTimeout(() => { window.location.href = "/pages/customer/dashboard.html"; }, 900);
    } catch {
      showMessage("Browser storage is unavailable. No profile was saved.", "error");
    }
  });

  const login = document.getElementById("login-form");
  if (login) login.addEventListener("submit", (event) => {
    event.preventDefault();
    const profile = readProfile();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;

    if (!password) return showMessage("Enter a password.", "error");
    if (profile && profile.email === email) {
      showMessage("Demo profile found. This is not secure authentication; opening the prototype dashboard.", "success");
      setTimeout(() => { window.location.href = "/pages/customer/dashboard.html"; }, 900);
    } else {
      showMessage("No matching demo profile found in this browser. Create a demo profile first. Real credential verification is not available.", "error");
    }
  });
});
