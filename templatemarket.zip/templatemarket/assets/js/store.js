(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const products = [
    {id:"luxe-commerce",name:"Luxe Commerce UI",category:"E-commerce",price:39,tag:"BESTSELLER",tone:"art-sand",seller:"Noah Studio",desc:"A polished storefront concept for modern premium brands.",features:["Responsive page layouts","Reusable UI sections","Organized design structure","Commercial use subject to seller license"]},
    {id:"aurora-portfolio",name:"Aurora Portfolio",category:"Portfolio",price:24,tag:"CREATIVE",tone:"art-purple",seller:"PixelCraft",desc:"A bold portfolio concept for creatives and independent studios.",features:["Portfolio landing concept","Project showcase sections","Responsive layout concept","Commercial use subject to seller license"]},
    {id:"saas-dashboard",name:"SaaS Dashboard Pro",category:"Dashboard",price:49,tag:"PRO PICK",tone:"art-blue",seller:"Nova Themes",desc:"A clean dashboard concept with analytics-focused components.",features:["Dashboard screen concept","Chart placeholders","Reusable card patterns","Commercial use subject to seller license"]},
    {id:"editorial-studio",name:"Editorial Studio",category:"Landing page",price:29,tag:"NEW",tone:"art-rose",seller:"Noah Studio",desc:"A refined editorial layout with strong typography and a clear hierarchy.",features:["Editorial landing page","Typography-led sections","Responsive design concept","Commercial use subject to seller license"]},
    {id:"green-commerce",name:"Evergreen Shop",category:"E-commerce",price:35,tag:"POPULAR",tone:"art-green",seller:"PixelCraft",desc:"A fresh product storefront concept with a calm visual language.",features:["Product-grid concept","Category browsing layout","Mobile-friendly design","Commercial use subject to seller license"]},
    {id:"creator-kit",name:"Creator Landing Kit",category:"Landing page",price:19,tag:"STARTER",tone:"art-orange",seller:"Studio North",desc:"A compact landing-page concept for creators and new projects.",features:["Hero and CTA sections","Feature layout","Responsive layout concept","Commercial use subject to seller license"]},
    {id:"agency-portfolio",name:"Agency Folio",category:"Portfolio",price:32,tag:"STUDIO",tone:"art-indigo",seller:"Studio North",desc:"An agency portfolio concept for presenting projects and services.",features:["Case-study layout","Services overview","Contact section concept","Commercial use subject to seller license"]},
    {id:"analytics-panel",name:"Insight Analytics",category:"Dashboard",price:44,tag:"DATA UI",tone:"art-cyan",seller:"Nova Themes",desc:"An analytics interface concept for presenting metrics clearly.",features:["Metric cards","Chart placeholders","Data table styling","Commercial use subject to seller license"]},
    {id:"minimal-store",name:"Minimal Goods",category:"E-commerce",price:27,tag:"MINIMAL",tone:"art-slate",seller:"Studio North",desc:"A minimal shopping layout focused on product presentation.",features:["Product detail concept","Storefront sections","Responsive layout concept","Commercial use subject to seller license"]}
  ];
  const safe = v => String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = n => "$"+Number(n).toFixed(2);
  function read(key) {
    try { const v=JSON.parse(localStorage.getItem("tm_store_"+key)); return Array.isArray(v)?v:[]; }
    catch { return []; }
  }
  function save(key,arr) {
    try { localStorage.setItem("tm_store_"+key,JSON.stringify(arr)); return true; }
    catch { alert("Browser storage is unavailable. Your change was not saved."); return false; }
  }
  function product(id){return products.find(p=>p.id===id);}
  function art(p,large=false){
    return `<div class="store-art ${safe(p.tone)}"><span class="store-tag">${safe(p.tag)}</span><div class="art-window"><div class="art-top"></div><div class="art-line"></div><div class="art-line short"></div><div class="art-blocks"><i></i><i></i></div></div></div>`;
  }
  function counts(){
    const cart=read("cart"),wish=read("wishlist");
    $$("[data-cart-count]").forEach(el=>el.textContent=cart.length);
    $$("[data-wishlist-count]").forEach(el=>el.textContent=wish.length);
  }
  function isSaved(id){return read("wishlist").includes(id);}
  function card(p){
    const saved=isSaved(p.id);
    return `<article class="store-product">${art(p)}<button class="store-heart ${saved?"saved":""}" data-wish="${safe(p.id)}" aria-label="${saved?"Remove from":"Add to"} wishlist" aria-pressed="${saved}">${saved?"♥":"♡"}</button><div class="store-product-info"><div class="store-product-meta"><span>${safe(p.category)}</span><span>★ 4.9 <span style="opacity:.65">demo</span></span></div><h3><a href="template-details.html?id=${encodeURIComponent(p.id)}">${safe(p.name)}</a></h3><p class="store-product-desc">${safe(p.desc)}</p><div class="store-product-bottom"><span class="store-price">${money(p.price)}</span><button class="store-btn" data-add="${safe(p.id)}">Add to cart</button></div></div></article>`;
  }
  function renderCatalog(){
    const grid=$("[data-store-grid]");if(!grid)return;
    const q=($("[data-store-search]")?.value||"").trim().toLowerCase();
    const cat=$("[data-store-category]")?.value||"All";
    const sort=$("[data-store-sort]")?.value||"featured";
    let rows=products.filter(p=>(cat==="All"||p.category===cat)&&[p.name,p.category,p.seller,p.desc].join(" ").toLowerCase().includes(q));
    if(sort==="price-low")rows.sort((a,b)=>a.price-b.price);
    if(sort==="price-high")rows.sort((a,b)=>b.price-a.price);
    if(sort==="name")rows.sort((a,b)=>a.name.localeCompare(b.name));
    grid.innerHTML=rows.length?rows.map(card).join(""):`<div class="store-empty"><h3>No templates found</h3><p>Try another search or category.</p><button class="store-btn secondary" data-clear-search>Clear filters</button></div>`;
    const total=$("[data-store-result-count]");if(total)total.textContent=`${rows.length} template${rows.length===1?"":"s"} found`;
    counts();
  }
  function detail(){
    const host=$("[data-template-detail]");if(!host)return;
    const id=new URLSearchParams(location.search).get("id");
    const p=product(id)||products[0];
    host.innerHTML=`<div>${art(p,true)}<div class="store-info-note">Preview artwork is generated with CSS. It is not a screenshot or a downloadable template file.</div></div><div><div class="store-eyebrow">${safe(p.category)} · Template preview</div><h1>${safe(p.name)}</h1><p class="store-muted">Created by ${safe(p.seller)}</p><p class="store-detail-desc">${safe(p.desc)}</p><div class="store-detail-price">${money(p.price)}</div><div class="store-detail-panel"><strong>Included in this listing</strong><ul class="store-feature-list">${p.features.map(f=>`<li>${safe(f)}</li>`).join("")}</ul><div class="store-detail-actions"><button class="store-btn" data-add="${safe(p.id)}">Add to cart</button><button class="store-btn secondary" data-wish="${safe(p.id)}">${isSaved(p.id)?"♥ Saved":"♡ Wishlist"}</button></div><p class="store-muted" style="font-size:11px;margin:0">Demo listing · No payment or actual file delivery is connected.</p></div></div>`;
    counts();
  }
  function renderCart(){
    const host=$("[data-cart-list]");if(!host)return;
    const ids=read("cart");
    const items=ids.map(product).filter(Boolean);
    host.innerHTML=items.length?items.map(p=>`<article class="store-cart-row"><div class="store-mini-art">◇</div><div class="store-cart-row-main"><h3>${safe(p.name)}</h3><p>${safe(p.category)} · Demo listing</p><strong>${money(p.price)}</strong></div><button class="store-btn secondary" data-remove-cart="${safe(p.id)}">Remove</button></article>`).join(""):`<div class="store-empty"><h3>Your cart is empty</h3><p>Explore the marketplace and add a template.</p><a class="store-btn" href="marketplace.html">Browse templates</a></div>`;
    const total=items.reduce((sum,p)=>sum+p.price,0);
    const sum=$("[data-cart-total]");if(sum)sum.textContent=money(total);
    const checkout=$("[data-demo-checkout]");if(checkout)checkout.disabled=!items.length;
    counts();
  }
  function renderWishlist(){
    const host=$("[data-wishlist-list]");if(!host)return;
    const items=read("wishlist").map(product).filter(Boolean);
    host.innerHTML=items.length?`<div class="store-grid">${items.map(card).join("")}</div>`:`<div class="store-empty"><h3>Your wishlist is empty</h3><p>Save templates you want to revisit.</p><a class="store-btn" href="marketplace.html">Discover templates</a></div>`;
    counts();
  }
  document.addEventListener("click",e=>{
    const add=e.target.closest("[data-add]");
    if(add){
      const id=add.dataset.add;if(!product(id))return;
      const cart=read("cart");
      if(!cart.includes(id))cart.push(id);
      if(save("cart",cart)){counts();add.textContent="Added ✓";setTimeout(()=>{if(add.isConnected)add.textContent="Add to cart";},1100);}
      return;
    }
    const wish=e.target.closest("[data-wish]");
    if(wish){
      const id=wish.dataset.wish;if(!product(id))return;
      let list=read("wishlist");
      list=list.includes(id)?list.filter(x=>x!==id):[...list,id];
      if(save("wishlist",list)){renderCatalog();renderWishlist();detail();}
      return;
    }
    const remove=e.target.closest("[data-remove-cart]");
    if(remove){if(save("cart",read("cart").filter(id=>id!==remove.dataset.removeCart)))renderCart();return;}
    if(e.target.closest("[data-clear-search]")){
      const s=$("[data-store-search]");if(s)s.value="";
      const c=$("[data-store-category]");if(c)c.value="All";
      const so=$("[data-store-sort]");if(so)so.value="featured";
      $$(".store-chip").forEach(x=>x.classList.toggle("active",x.dataset.categoryChip==="All"));
      renderCatalog();return;
    }
    const chip=e.target.closest("[data-category-chip]");
    if(chip){
      const c=$("[data-store-category]");if(c)c.value=chip.dataset.categoryChip;
      $$(".store-chip").forEach(x=>x.classList.toggle("active",x===chip));
      renderCatalog();
    }
  });
  $$("[data-store-search]").forEach(el=>el.addEventListener("input",renderCatalog));
  $$("[data-store-category],[data-store-sort]").forEach(el=>el.addEventListener("change",()=>{
    const c=$("[data-store-category]");
    $$(".store-chip").forEach(x=>x.classList.toggle("active",x.dataset.categoryChip===(c?.value||"All")));
    renderCatalog();
  }));
  const checkout=$("[data-demo-checkout]");
  if(checkout)checkout.addEventListener("click",()=>alert("Demo only: checkout is not connected. No payment was taken and no order was created."));
  renderCatalog();detail();renderCart();renderWishlist();counts();
})();
