(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const demo = {
    users: [
      {name:"Ava Williams",email:"ava@example.test",role:"Customer",status:"Active"},
      {name:"Noah Studio",email:"noah@example.test",role:"Seller",status:"Active"},
      {name:"PixelCraft",email:"pixel@example.test",role:"Seller",status:"Pending"},
      {name:"Mia Johnson",email:"mia@example.test",role:"Customer",status:"Active"},
      {name:"Nova Themes",email:"nova@example.test",role:"Seller",status:"Blocked"}
    ],
    templates: [
      {name:"Luxe Commerce UI",category:"E-commerce",seller:"Noah Studio",price:39,status:"Pending"},
      {name:"Aurora Portfolio",category:"Portfolio",seller:"PixelCraft",price:24,status:"Approved"},
      {name:"SaaS Dashboard Pro",category:"Dashboard",seller:"Nova Themes",price:49,status:"Pending"},
      {name:"Editorial Studio",category:"Landing page",seller:"Noah Studio",price:29,status:"Approved"}
    ],
    orders: [
      {id:"TB-1048",customer:"Olivia M.",item:"Luxe Commerce UI",total:39,status:"Completed"},
      {id:"TB-1047",customer:"Ethan R.",item:"SaaS Dashboard Pro",total:49,status:"Processing"},
      {id:"TB-1046",customer:"Sophia K.",item:"Aurora Portfolio",total:24,status:"Completed"},
      {id:"TB-1045",customer:"Liam P.",item:"Editorial Studio",total:29,status:"Refunded"}
    ]
  };
  const safe = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = n => "$" + Number(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
  function read(key) {
    try { const v=JSON.parse(localStorage.getItem("tm_admin_"+key)); return Array.isArray(v)?v:demo[key].map(x=>({...x})); }
    catch { return demo[key].map(x=>({...x})); }
  }
  function write(key, rows) {
    try { localStorage.setItem("tm_admin_"+key,JSON.stringify(rows)); return true; }
    catch { alert("Browser storage is unavailable. Changes were not saved."); return false; }
  }
  function statusClass(s) {
    if (/pending|processing/i.test(s)) return "pending";
    if (/blocked|refunded|rejected/i.test(s)) return "blocked";
    return "";
  }
  function badge(s) { return `<span class="admin-status ${statusClass(s)}">${safe(s)}</span>`; }
  function renderTable(key) {
    const tbody=$(`[data-admin-table="${key}"]`);
    if(!tbody) return;
    const rows=read(key);
    const query=($(`[data-admin-search="${key}"]`)?.value||"").toLowerCase();
    const filtered=rows.filter(r=>Object.values(r).join(" ").toLowerCase().includes(query));
    tbody.innerHTML=filtered.length?filtered.map((r,i)=>{
      if(key==="users") return `<tr><td>${safe(r.name)}<br><span style="color:var(--ad-muted);font-weight:400">${safe(r.email)}</span></td><td>${safe(r.role)}</td><td>${badge(r.status)}</td><td><button class="admin-btn secondary" data-row-action="toggle" data-key="${key}" data-index="${rows.indexOf(r)}">Change status</button></td></tr>`;
      if(key==="templates") return `<tr><td>${safe(r.name)}</td><td>${safe(r.seller)}</td><td>${safe(r.category)}</td><td>${money(r.price)}</td><td>${badge(r.status)}</td><td><button class="admin-btn secondary" data-row-action="toggle" data-key="${key}" data-index="${rows.indexOf(r)}">Review</button></td></tr>`;
      return `<tr><td>${safe(r.id)}</td><td>${safe(r.customer)}</td><td>${safe(r.item)}</td><td>${money(r.total)}</td><td>${badge(r.status)}</td><td><button class="admin-btn secondary" data-row-action="toggle" data-key="${key}" data-index="${rows.indexOf(r)}">Update</button></td></tr>`;
    }).join(""):`<tr><td colspan="6" class="admin-empty">No matching records found.</td></tr>`;
  }
  function canvasChart() {
    const canvas=$("#adminRevenueChart");
    if(!canvas) return;
    const ctx=canvas.getContext("2d"); if(!ctx) return;
    const rect=canvas.getBoundingClientRect(); if(!rect.width||!rect.height) return;
    const dpr=window.devicePixelRatio||1;
    canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);
    ctx.scale(dpr,dpr);
    const w=rect.width,h=rect.height,pad={l:38,r:10,t:14,b:27};
    const vals=[18,29,24,43,37,56,49,65,58,79,71,92];
    const labels=["Nov","Dec","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct"];
    const cw=w-pad.l-pad.r,ch=h-pad.t-pad.b;
    ctx.font="11px system-ui";ctx.lineWidth=1;
    for(let i=0;i<5;i++){
      const y=pad.t+ch*i/4;ctx.strokeStyle="#293142";ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();
      ctx.fillStyle="#929bad";ctx.fillText("$"+(100-i*25)+"k",2,y+4);
    }
    const points=vals.map((v,i)=>({x:pad.l+cw*i/(vals.length-1),y:pad.t+ch*(1-v/100)}));
    const gradient=ctx.createLinearGradient(0,pad.t,0,h-pad.b);
    gradient.addColorStop(0,"rgba(233,189,105,.28)");gradient.addColorStop(1,"rgba(233,189,105,0)");
    ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
    ctx.lineTo(points[points.length-1].x,h-pad.b);ctx.lineTo(points[0].x,h-pad.b);ctx.closePath();ctx.fillStyle=gradient;ctx.fill();
    ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
    ctx.strokeStyle="#e9bd69";ctx.lineWidth=2.5;ctx.stroke();
    points.forEach((p,i)=>{if(i===points.length-1){ctx.beginPath();ctx.arc(p.x,p.y,4,0,Math.PI*2);ctx.fillStyle="#e9bd69";ctx.fill();}});
    labels.forEach((label,i)=>{if(w<400&&i%2) return;ctx.fillStyle="#929bad";ctx.fillText(label,pad.l+cw*i/(labels.length-1)-10,h-7);});
  }
  function showNotice(message) {
    const el=$("[data-admin-notice]");
    if(el){el.textContent=message;el.hidden=false;}
  }
  document.addEventListener("click",e=>{
    const btn=e.target.closest("[data-row-action]");
    if(!btn)return;
    const key=btn.dataset.key,rows=read(key),i=Number(btn.dataset.index),r=rows[i];
    if(!r)return;
    if(key==="users") r.status=r.status==="Blocked"?"Active":"Blocked";
    else if(key==="templates") r.status=r.status==="Approved"?"Rejected":"Approved";
    else r.status=r.status==="Completed"?"Processing":"Completed";
    if(write(key,rows)){renderTable(key);showNotice("Demo record updated in this browser only.");}
  });
  $$("[data-admin-search]").forEach(el=>el.addEventListener("input",()=>renderTable(el.dataset.adminSearch)));
  $$("[data-admin-reset]").forEach(btn=>btn.addEventListener("click",()=>{
    const key=btn.dataset.adminReset;
    if(confirm("Reset "+key+" to the original demo records?")){
      try{localStorage.removeItem("tm_admin_"+key);}catch{}
      renderTable(key);showNotice("Demo records reset.");
    }
  }));
  const form=$("[data-admin-settings]");
  if(form){
    try {
      const saved=JSON.parse(localStorage.getItem("tm_admin_settings")||"{}");
      Object.entries(saved).forEach(([k,v])=>{const el=form.elements.namedItem(k);if(el)el.value=v;});
    } catch {}
    form.addEventListener("submit",e=>{
      e.preventDefault();const data={};
      [...form.elements].forEach(el=>{if(el.name)data[el.name]=el.value;});
      try{localStorage.setItem("tm_admin_settings",JSON.stringify(data));showNotice("Demo settings saved in this browser.");}
      catch{showNotice("Browser storage unavailable; settings could not be saved.");}
    });
  }
  ["users","templates","orders"].forEach(renderTable);
  canvasChart();
  window.addEventListener("resize",canvasChart);
})();
