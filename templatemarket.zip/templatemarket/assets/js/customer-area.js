"use strict";

document.addEventListener("DOMContentLoaded", () => {
  let profile = null;
  try {
    profile = JSON.parse(localStorage.getItem("templatemarket_demo_profile_v1") || "null");
  } catch { /* Ignore malformed demo data. */ }

  const name = profile && profile.name ? profile.name : "Guest customer";
  const email = profile && profile.email ? profile.email : "No demo profile saved";

  document.querySelectorAll("#customer-name").forEach(el => el.textContent = name);
  document.querySelectorAll("#customer-email").forEach(el => el.textContent = email);
  document.querySelectorAll("#customer-avatar").forEach(el => {
    el.textContent = name.charAt(0).toUpperCase();
  });

  const settingsName = document.getElementById("settings-name");
  const settingsEmail = document.getElementById("settings-email");
  if (settingsName) settingsName.value = name;
  if (settingsEmail) settingsEmail.value = email;

  const logout = document.getElementById("logout");
  if (logout) logout.addEventListener("click", () => {
    // This only clears demo profile data, not a real server session.
    try { localStorage.removeItem("templatemarket_demo_profile_v1"); } catch {}
    window.location.href = "/pages/login.html";
  });
});
