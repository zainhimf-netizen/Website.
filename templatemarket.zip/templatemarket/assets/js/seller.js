"use strict";

/*
 * TemplateMarket seller UI prototype.
 * Data is kept in this browser only. This is NOT a secure marketplace backend.
 */
const TM_SELLER_KEY = "templatemarket_seller_products_v1";
const TM_SELLER_DEMO = [
  {id:"demo-1",title:"Studio Portfolio",category:"Website Template",price:19,status:"Demo",description:"A sample portfolio template.",createdAt:"Demo"},
  {id:"demo-2",title:"Analytics Suite",category:"Dashboard UI Kit",price:29,status:"Demo",description:"A sample dashboard UI kit.",createdAt:"Demo"}
];

function tmLoadProducts() {
  try {
    const value = JSON.parse(localStorage.getItem(TM_SELLER_KEY) || "null");
    return Array.isArray(value) ? value : [];
  } catch { return []; }
}
function tmSaveProducts(products) {
  localStorage.setItem(TM_SELLER_KEY, JSON.stringify(products));
}
function tmEscape(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  })[ch]);
}
function tmMoney(value) {
  return "$" + Number(value || 0).toFixed(2);
}
function tmShowMessage(text, type="success") {
  const el = document.getElementById("seller-message");
  if (!el) return;
  el.textContent = text;
  el.className = "seller-message show " + type;
}
function tmProductRows(products) {
  const body = document.getElementById("seller-product-rows");
  if (!body) return;
  if (!products.length) {
    body.innerHTML = '<tr><td colspan="5">No products yet. Add your first template.</td></tr>';
    return;
  }
  body.innerHTML = products.map(p => `<tr>
    <td>${tmEscape(p.title)}</td>
    <td>${tmEscape(p.category)}</td>
    <td>${tmMoney(p.price)}</td>
    <td><span class="status">${tmEscape(p.status || "Draft")}</span></td>
    <td><button class="btn btn-secondary btn-small" type="button" data-delete-product="${tmEscape(p.id)}">Delete</button></td>
  </tr>`).join("");
}
function tmDrawChart(canvas, values, labels) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(280, rect.width);
  const h = 220;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  ctx.scale(dpr,dpr);
  ctx.clearRect(0,0,w,h);
  const pad = {l:38,r:12,t:18,b:32};
  const cw = w-pad.l-pad.r, ch = h-pad.t-pad.b;
  const max = Math.max(10,...values)*1.15;
  ctx.font = "11px system-ui";
  ctx.strokeStyle = "#29364d";
  ctx.fillStyle = "#9ba8bd";
  ctx.lineWidth = 1;
  for (let i=0;i<=4;i++) {
    const y=pad.t+ch*i/4;
    ctx.beginPath(); ctx.moveTo(pad.l,y); ctx.lineTo(w-pad.r,y); ctx.stroke();
    ctx.fillText(String(Math.round(max*(4-i)/4)),3,y+4);
  }
  const pts=values.map((v,i)=>({
    x:pad.l+(values.length===1?cw/2:cw*i/(values.length-1)),
    y:pad.t+ch-(v/max)*ch
  }));
  ctx.beginPath();
  pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
  ctx.strokeStyle="#e9c27b"; ctx.lineWidth=2.5; ctx.stroke();
  pts.forEach((p,i)=>{
    ctx.beginPath(); ctx.arc(p.x,p.y,3.5,0,Math.PI*2);
    ctx.fillStyle="#e9c27b"; ctx.fill();
    if(labels[i]) ctx.fillText(labels[i],Math.max(0,p.x-12),h-10);
  });
}

document.addEventListener("DOMContentLoaded",()=>{
  const products=tmLoadProducts();
  const count=document.getElementById("seller-product-count");
  if(count) count.textContent=String(products.length);
  tmProductRows(products);

  const total=document.getElementById("seller-total-value");
  if(total) total.textContent=tmMoney(products.reduce((sum,p)=>sum+Number(p.price||0),0));

  tmDrawChart(document.getElementById("earnings-chart"),[120,180,145,260,220,310,285],["M","T","W","T","F","S","S"]);
  tmDrawChart(document.getElementById("sales-chart"),[3,5,4,8,6,11,9],["M","T","W","T","F","S","S"]);

  const form=document.getElementById("seller-product-form");
  if(form) form.addEventListener("submit",event=>{
    event.preventDefault();
    const title=document.getElementById("product-title").value.trim();
    const category=document.getElementById("product-category").value;
    const price=Number(document.getElementById("product-price").value);
    const description=document.getElementById("product-description").value.trim();
    if(title.length<3) return tmShowMessage("Title must contain at least 3 characters.","error");
    if(!Number.isFinite(price)||price<0||price>100000) return tmShowMessage("Enter a valid price.","error");

    const updated=tmLoadProducts();
    updated.unshift({
      id: "local-"+Date.now()+"-"+Math.random().toString(36).slice(2,7),
      title,category,price,description,status:"Local draft",
      createdAt:new Date().toISOString()
    });
    try {
      tmSaveProducts(updated);
      tmProductRows(updated);
      const c=document.getElementById("seller-product-count");
      if(c)c.textContent=String(updated.length);
      const totalValue=document.getElementById("seller-total-value");
      if(totalValue)totalValue.textContent=tmMoney(updated.reduce((sum,p)=>sum+Number(p.price||0),0));
      form.reset();
      tmShowMessage("Product draft saved in this browser only. It is not published or uploaded to a server.");
    } catch {
      tmShowMessage("Could not save draft. Check browser storage.","error");
    }
  });

  document.addEventListener("click",event=>{
    const btn=event.target.closest("[data-delete-product]");
    if(!btn)return;
    const id=btn.getAttribute("data-delete-product");
    const next=tmLoadProducts().filter(p=>p.id!==id);
    try {
      tmSaveProducts(next); tmProductRows(next);
      const c=document.getElementById("seller-product-count");
      if(c)c.textContent=String(next.length);
      const totalValue=document.getElementById("seller-total-value");
      if(totalValue)totalValue.textContent=tmMoney(next.reduce((sum,p)=>sum+Number(p.price||0),0));
      tmShowMessage("Local draft removed.");
    } catch { tmShowMessage("Could not update browser storage.","error"); }
  });

  window.addEventListener("resize",()=>{
    tmDrawChart(document.getElementById("earnings-chart"),[120,180,145,260,220,310,285],["M","T","W","T","F","S","S"]);
    tmDrawChart(document.getElementById("sales-chart"),[3,5,4,8,6,11,9],["M","T","W","T","F","S","S"]);
  });
});
